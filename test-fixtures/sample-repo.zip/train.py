"""Training script for ResNet on CIFAR-10."""
import torch
import torch.nn as nn
import torch.optim as optim
from models.resnet import resnet18


def train():
    model = resnet18()
    images = torch.randn(64, 3, 32, 32)
    labels = torch.randint(0, 10, (64,))

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)

    logits = model(images)
    loss = criterion(logits, labels)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    print(f"Loss: {loss.item():.4f}")


if __name__ == "__main__":
    train()
