# ResNet CIFAR-10

A PyTorch implementation of ResNet for CIFAR-10 classification.

## Usage
```bash
python train.py
```
